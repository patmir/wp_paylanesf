=== Plugin Name ===
Contributors: patmir
Donate link: patmir.com
Tags: paylane, secureform
Requires at least: 5.0.1
Tested up to: 5.1.1
Stable tag: 5.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Implementacja SecureForm Paylane dla darowizn

== Description ==

Implementacja SecureForm Paylane dla darowizn

== Installation ==

Zainstaluj, Aktywuj, w Ustawieniach wybierz kwoty, podaj merchant_id i salta.

== Changelog ==
= 1.1 =
Dodano dowolną kwotę, regulamin oraz nadpis ustawień z poziomu widget'u
= 1.0 =
* Będzie żyć ;).